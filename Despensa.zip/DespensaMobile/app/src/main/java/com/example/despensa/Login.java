package com.example.despensa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    EditText edtUser, edtPwd;
    Button btnLogin;
    TextView tvUsuario, tvSenha, tvCriarConta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        InicializarComponentes();

        //verificação de usuário e senha
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuario = edtUser.getText().toString();
                String senha = edtPwd.getText().toString();

                if (usuario.isEmpty() || senha.isEmpty()) {
                    UsarMetodo.alert("Não deixe em branco!!", getApplicationContext());
                } else if (UsarMetodo.login(usuario, senha)) {
                    Intent intent = new Intent(Login.this, TelaInicial.class);
                    intent.putExtra("chave", usuario);
                    startActivity(intent);
                } else {
                    UsarMetodo.alert("Usuário ou senha estão incorretos",
                            getApplicationContext());
                }


            }

        });
        //botão link para tela de cadastro
        tvCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, TelaCadastro.class);
                startActivity(intent);
            }
        });


    }

    private void InicializarComponentes() {
        edtUser = findViewById(R.id.edtUser);
        edtPwd = findViewById(R.id.edtPwd);
        btnLogin = findViewById(R.id.btnLogin);
        tvUsuario = findViewById(R.id.tvUsuario);
        tvSenha = findViewById(R.id.tvSenha);
        tvCriarConta = findViewById(R.id.tvCriarConta);
    }

    public void sair(View view) {
        finish();
    }
}